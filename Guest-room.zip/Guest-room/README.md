# Guest-room
Guest room online booking portal
This is my first backend project
# Languages used
Html,css,js,php and mysqli.
# How it works
First you check guest room availablity. 
Then fillup form. 
Then you will recieve a mail by hall office of approval. 
After that you are required to pay the fee. 
Then submit recipt at the hall office and collect keys on the respective day of room booking.